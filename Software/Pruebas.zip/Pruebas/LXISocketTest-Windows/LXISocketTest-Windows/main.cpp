﻿/*
 * Created by SharpDevelop.
 * User: Administrador
 * Date: 24/05/2017
 * Time: 16:34
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using namespace System;

int main(array<System::String ^> ^args)
{
	Console::WriteLine(L"Hello World");
	return 0;
}
