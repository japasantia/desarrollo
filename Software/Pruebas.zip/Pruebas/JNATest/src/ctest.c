 
#include <stdio.h>

void helloFromC() 
{
  printf("Hello freom C!\n");  
}