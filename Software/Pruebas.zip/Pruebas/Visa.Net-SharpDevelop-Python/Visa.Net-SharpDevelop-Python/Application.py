﻿import wpf

from System.Windows import Application
from Window1 import Window1

window = Window1()
app = Application()
app.Run(window)
